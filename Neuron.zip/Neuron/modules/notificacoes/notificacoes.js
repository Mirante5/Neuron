/**
 * @file notificacoes.js
 * @version Final (com Botões de Ação)
 * @description Versão final com botões de "Atualizar" e "Limpar Lista" no painel,
 * e com toda a lógica de armazenamento e renderização.
 */

window.addEventListener('load', () => {
    'use strict';
    console.log("NOTIFICACOES: Script Final (com Botões de Ação) iniciado.");

    // --- 1. Constantes e Estado ---
    const STORAGE_KEY_DEMANDAS = 'neuronDemandasMestra';
    const STORAGE_KEY_CONCLUIDAS = 'neuronDemandasConcluidas';
    let demandasConcluidas = new Set();
    let memoriaDeDemandas = {};

    // --- 2. Criação da UI ---
    const trigger = document.createElement('div');
    trigger.id = 'neuron-notificacao-trigger';
    trigger.title = 'Abrir Notificações';
    trigger.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 16 16"><path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2m.995-14.901a1 1 0 1 0-1.99 0A5 5 0 0 0 3 6c0 1.098-.5 6-2 7h14c-1.5-1-2-5.902-2-7 0-2.42-1.72-4.44-4.005-4.901"/></svg>`;
    const contador = document.createElement('span');
    contador.className = 'neuron-contador';
    contador.style.display = 'none';
    trigger.appendChild(contador);
    document.body.appendChild(trigger);
    
    const painel = document.createElement('div');
    painel.id = 'neuron-notificacao-painel';
    painel.innerHTML = `
        <div class="neuron-painel-header">
            <h4>Notificações</h4>
            <button class="neuron-painel-close" title="Fechar">&times;</button>
        </div>
        <div class="neuron-painel-body">
            <p>A carregar dados...</p>
        </div>
        <div class="neuron-painel-footer">
            <button id="neuron-btn-atualizar" class="neuron-footer-btn neuron-btn-atualizar">Atualizar</button>
            <button id="neuron-btn-limpar" class="neuron-footer-btn neuron-btn-limpar">Limpar Lista</button>
        </div>
    `;
    document.body.appendChild(painel);

    // --- 3. Lógica de Interação da UI ---
    const closeButton = painel.querySelector('.neuron-painel-close');
    const btnAtualizar = document.getElementById('neuron-btn-atualizar');
    const btnLimpar = document.getElementById('neuron-btn-limpar');

    trigger.addEventListener('click', () => {
        painel.style.display = painel.style.display === 'flex' ? 'none' : 'flex';
    });
    closeButton.addEventListener('click', () => {
        painel.style.display = 'none';
    });

    btnAtualizar.addEventListener('click', () => {
        console.log("NOTIFICACOES: Botão 'Atualizar' clicado. Solicitando novos dados...");
        document.dispatchEvent(new CustomEvent('NEURON_SOLICITAR_ATUALIZACAO'));
        btnAtualizar.innerText = 'A atualizar...';
        setTimeout(() => { btnAtualizar.innerText = 'Atualizar'; }, 1500);
    });

    btnLimpar.addEventListener('click', () => {
        if (confirm('Tem a certeza de que deseja limpar toda a lista de notificações e demandas concluídas?')) {
            console.log("NOTIFICACOES: Limpando toda a memória...");
            memoriaDeDemandas = {};
            demandasConcluidas = new Set();
            chrome.storage.local.remove([STORAGE_KEY_DEMANDAS, STORAGE_KEY_CONCLUIDAS]);
            renderizarPainel([]);
        }
    });

    // --- 4. Lógica Principal ---
    function inicializar() {
        chrome.storage.local.get([STORAGE_KEY_CONCLUIDAS, STORAGE_KEY_DEMANDAS], (result) => {
            if (result[STORAGE_KEY_CONCLUIDAS] && Array.isArray(result[STORAGE_KEY_CONCLUIDAS])) {
                demandasConcluidas = new Set(result[STORAGE_KEY_CONCLUIDAS]);
            }
            if (result[STORAGE_KEY_DEMANDAS] && Object.keys(result[STORAGE_KEY_DEMANDAS]).length > 0) {
                memoriaDeDemandas = result[STORAGE_KEY_DEMANDAS];
                renderizarPainel(Object.values(memoriaDeDemandas));
            } else {
                renderizarPainel([]);
            }
        });
    }

    document.addEventListener('dadosExtraidosNeuron', (event) => {
        if (!event.detail || !Array.isArray(event.detail)) return;
        const demandasDaPagina = event.detail;
        demandasDaPagina.forEach(demanda => {
            if (demanda && demanda.numero) {
                memoriaDeDemandas[demanda.numero] = demanda;
            }
        });
        chrome.storage.local.set({ [STORAGE_KEY_DEMANDAS]: memoriaDeDemandas });
        renderizarPainel(Object.values(memoriaDeDemandas));
    });

    // --- Funções de Renderização e Lógica ---
    function renderizarPainel(listaMestra) {
        const corpoDoPainel = painel.querySelector('.neuron-painel-body');
        const notificacoesRelevantes = listaMestra.filter(isNotificacaoRelevante);
        
        const prorrogadas = notificacoesRelevantes.filter(d => d.situacao.includes('Prorrogada'));
        const complementadas = notificacoesRelevantes.filter(d => d.situacao.includes('Complementada'));
        const prazosCurtos = notificacoesRelevantes.filter(d => d.prazo).map(d => ({ ...d, diasRestantes: calcularDiasRestantes(parsearData(d.prazo)) })).filter(d => d.diasRestantes !== null && d.diasRestantes <= 2).sort((a, b) => a.diasRestantes - b.diasRestantes);
        const respondidas = notificacoesRelevantes.filter(d => d.possivelRespondida);
        const observacao = notificacoesRelevantes.filter(d => d.possivelobservacao);

        const criarGrupoHTML = (titulo, lista) => {
            if (lista.length === 0) return '';
            let grupoHtml = `<div class="neuron-grupo-notificacao"><h5>${titulo} (${lista.length})</h5>`;
            lista.forEach(d => {
                const isDone = demandasConcluidas.has(d.numero);
                const detalhePrazo = (d.diasRestantes !== null && d.diasRestantes !== undefined) ? `<span class="neuron-link-detalhe">Prazo em ${d.diasRestantes} dias</span>` : '';
                grupoHtml += `<div class="neuron-item-notificacao ${isDone ? 'done' : ''}" data-numero="${d.numero}" data-href="${d.href || '#'}"><div class="neuron-link-wrapper"><span class="neuron-link-numero">${d.numero}</span>${detalhePrazo}</div><input type="checkbox" class="neuron-done-check" title="Marcar como concluído" ${isDone ? 'checked' : ''}></div>`;
            });
            return grupoHtml + '</div>';
        };
        
        let html = criarGrupoHTML('Prazos Curtos (<= 2 dias)', prazosCurtos);
        html += criarGrupoHTML('Possíveis Respondidas', respondidas);
        html += criarGrupoHTML('Com Observação', observacao);
        html += criarGrupoHTML('Demandas Prorrogadas', prorrogadas);
        html += criarGrupoHTML('Demandas Complementadas', complementadas);
        
        corpoDoPainel.innerHTML = html || '<p>Nenhuma notificação relevante encontrada.</p>';
        adicionarEventListenersAosItens();
        atualizarContadorEIcone();
    }
    
    function adicionarEventListenersAosItens() {
        painel.querySelectorAll('.neuron-item-notificacao').forEach(item => {
            item.querySelector('.neuron-link-wrapper').addEventListener('click', (e) => {
                e.stopPropagation();
                const numero = item.dataset.numero;
                const href = item.dataset.href;
                if (!href || href === '#') return;
                const urlRelativo = href.split('.gov.br')[1];
                const elementoNaPagina = urlRelativo ? document.querySelector(`a[navigateurl="${urlRelativo}"]`) : null;
                if (elementoNaPagina) {
                    elementoNaPagina.scrollIntoView({ behavior: 'smooth', block: 'center' });
                } else {
                    alert(`Demanda ${numero} não encontrada na página atual. A abrir em nova aba.`);
                }
                window.open(href, '_blank');
            });
            
            item.querySelector('.neuron-done-check').addEventListener('change', (e) => {
                const numero = item.dataset.numero;
                if (e.target.checked) demandasConcluidas.add(numero);
                else demandasConcluidas.delete(numero);
                chrome.storage.local.set({ [STORAGE_KEY_CONCLUIDAS]: Array.from(demandasConcluidas) });
                atualizarContadorEIcone();
            });
        });
    }

    function atualizarContadorEIcone() {
        const notificacoesRelevantes = Object.values(memoriaDeDemandas).filter(isNotificacaoRelevante);
        const naoConcluidas = notificacoesRelevantes.filter(d => !demandasConcluidas.has(d.numero));
        const total = naoConcluidas.length;
        if (total > 0) {
            contador.innerText = total;
            contador.style.display = 'block';
            trigger.classList.add('has-new');
            trigger.style.backgroundColor = total <= 10 ? '#ffc107' : '#dc3545';
        } else {
            contador.style.display = 'none';
            trigger.classList.remove('has-new');
            trigger.style.backgroundColor = '#007bff';
        }
    }
    
    function isNotificacaoRelevante(demanda) {
        if (!demanda || typeof demanda !== 'object') return false;
        const situacao = demanda.situacao || '';
        const prazo = demanda.prazo || '';
        const diasRestantes = calcularDiasRestantes(parsearData(prazo));
        const isProrrogada = situacao.includes('Prorrogada');
        const isComplementada = situacao.includes('Complementada');
        return (diasRestantes !== null && diasRestantes <= 2) || isProrrogada || isComplementada || demanda.possivelRespondida || demanda.possivelobservacao;
    }
    
    function parsearData(dataString) {
        if (!dataString) return null;
        const partes = dataString.split('/');
        return new Date(partes[2], partes[1] - 1, partes[0]);
    }

    function calcularDiasRestantes(dataAlvo) {
        if (!dataAlvo) return null;
        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);
        return Math.ceil((dataAlvo.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
    }

    inicializar();
});