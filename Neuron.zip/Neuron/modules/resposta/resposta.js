// Neuron/modules/resposta/resposta.js (Atualizado para clique direto no input)

(function() {
    'use strict';

    const RespostaModule = {
        fullConfig: {},
        defaultConfig: {},
        ui: {},
        isInitialized: false,

        async loadConfig() {
            try {
                const response = await fetch(chrome.runtime.getURL('config/config.json'));
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                this.defaultConfig = await response.json();

                const result = await chrome.storage.local.get('neuronUserConfig');
                const userConfig = result.neuronUserConfig || {};

                this.fullConfig = this.deepMerge(JSON.parse(JSON.stringify(this.defaultConfig)), userConfig);
                console.log('Neuron [Resposta]: Configuração carregada.');
            } catch (error) {
                console.error('Neuron [Resposta]: ERRO CRÍTICO ao carregar configuração.', error);
                this.fullConfig = this.defaultConfig;
            }
        },

        deepMerge(target, source) {
            const isObject = (item) => item && typeof item === 'object' && !Array.isArray(item);
            if (isObject(target) && isObject(source)) {
                for (const key in source) {
                    if (isObject(source[key])) {
                        if (!target[key]) Object.assign(target, { [key]: {} });
                        this.deepMerge(target[key], source[key]);
                    } else {
                        Object.assign(target, { [key]: source[key] });
                    }
                }
            }
            return target;
        },

        renderNovoDropdown(tipoResposta) {
            const optionsData = this.fullConfig.defaultResponses[tipoResposta]?.novoDropdownOptions;

            this.ui.novoDropdownInput.value = '';
            this.ui.txtRespostaTextarea.value = '';
            this.ui.responsavelRespostaInput.value = '';
            this.ui.novoDropdownList.innerHTML = '';
            this.ui.novoDropdownInput.setAttribute('disabled', 'disabled');

            if (optionsData && Array.isArray(optionsData) && optionsData.length > 0) {
                this.ui.novoDropdownInput.removeAttribute('disabled');
                optionsData.forEach((option, index) => {
                    const item = document.createElement('div');
                    item.className = 'br-item';
                    item.setAttribute('tabindex', '-1');
                    item.innerHTML = `
                        <div class="br-radio">
                            <input id="neuron-novoDropdown-item-${index}" type="radio" value="${option.text}">
                            <label for="neuron-novoDropdown-item-${index}">${option.text}</label>
                        </div>`;
                    this.ui.novoDropdownList.appendChild(item);
                    item.addEventListener('click', () => this.selectDropdownOption(item, option));
                });
            }
        },

        selectDropdownOption(itemElement, optionData) {
            Array.from(this.ui.novoDropdownList.children).forEach(child => child.classList.remove('selected'));
            itemElement.classList.add('selected');
            this.ui.novoDropdownInput.value = optionData.text || '';
            this.ui.txtRespostaTextarea.value = optionData.conteudoTextarea || '';
            this.ui.responsavelRespostaInput.value = optionData.responsavel || '';
            this.ui.novoDropdownList.style.display = 'none';
        },

        addListeners() {
            // Listener no dropdown de TIPO de resposta
            this.ui.slTipoRespostaList.addEventListener('click', (event) => {
                const clickedItem = event.target.closest('.br-item');
                if (clickedItem) {
                    const selectedText = clickedItem.querySelector('label')?.textContent.trim();
                    if (selectedText) this.renderNovoDropdown(selectedText);
                }
            });

            // ***** MODIFICAÇÃO PRINCIPAL *****
            // Listener para abrir/fechar o dropdown ao CLICAR NO INPUT
            this.ui.novoDropdownInput.addEventListener('click', () => {
                if (!this.ui.novoDropdownInput.hasAttribute('disabled')) {
                    const isHidden = this.ui.novoDropdownList.style.display !== 'block';
                    this.ui.novoDropdownList.style.display = isHidden ? 'block' : 'none';
                }
            });

            // Listener para fechar o dropdown se clicar fora dele
            const novoDropdownContainer = document.getElementById('neuron-novoDropdown');
            document.addEventListener('click', (event) => {
                if (!novoDropdownContainer.contains(event.target)) {
                    this.ui.novoDropdownList.style.display = 'none';
                }
            });
        },

        async init() {
            if (this.isInitialized || !document.getElementById('slTipoResposta')) return;
            this.isInitialized = true;
            console.log('Neuron [Resposta]: Inicializando módulo.');

            await this.loadConfig();

            if (!document.getElementById('neuron-novoDropdown')) {
                // ***** MODIFICAÇÃO PRINCIPAL *****
                // Nova estrutura HTML sem botões, com ícone dentro do input.
                const novoDropdownHTML = `
                    <div class="br-select mb-3" id="neuron-novoDropdown">
                        <label for="neuron-novoDropdown-input">Opções de Resposta (Neuron)</label>
                        <div class="br-input has-icon">
                            <input id="neuron-novoDropdown-input" type="text" placeholder="Clique para selecionar..." readonly disabled autocomplete="off">
                            <button class="br-button circle" type="button" aria-label="Exibir lista" tabindex="-1">
                                <i class="fas fa-angle-down" aria-hidden="true"></i>
                            </button>
                        </div>
                        <div class="br-list" id="neuron-novoDropdown-list" tabindex="-1"></div>
                    </div>`;
                document.getElementById('slTipoResposta').insertAdjacentHTML('afterend', novoDropdownHTML);
            }

            this.ui = {
                slTipoRespostaList: document.getElementById('slTipoResposta-list'),
                txtRespostaTextarea: document.getElementById('txtResposta-textarea'),
                responsavelRespostaInput: document.getElementById('responsavelResposta-input'),
                novoDropdownInput: document.getElementById('neuron-novoDropdown-input'),
                novoDropdownList: document.getElementById('neuron-novoDropdown-list')
            };

            this.addListeners();

            chrome.storage.onChanged.addListener((changes, namespace) => {
                if (namespace === 'local' && changes.neuronUserConfig) {
                    console.log('Neuron [Resposta]: Configuração alterada, recarregando...');
                    this.init();
                }
            });
        }
    };

    const observer = new MutationObserver(() => {
        if (document.getElementById('slTipoResposta') && document.getElementById('txtResposta-textarea')) {
            RespostaModule.init();
            observer.disconnect();
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

})();