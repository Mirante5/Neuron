/**
 * @file tratar_novo_insert.js
 * @description Modifica o comportamento dos links de número de demanda. Em vez de navegar,
 * o clique irá copiar o número para a área de transferência e exibir uma notificação.
 */

function modificarLinksParaCopiar() {
    console.log("Iniciando script para modificar links (v1)...");

    // Função que cria e exibe a notificação de "copiado"
    function showCopyNotification(text) {
        // Cria o elemento da notificação
        const notification = document.createElement('div');
        notification.innerText = text;

        // Estiliza a notificação
        notification.style.position = 'fixed';
        notification.style.bottom = '20px';
        notification.style.left = '50%';
        notification.style.transform = 'translateX(-50%)';
        notification.style.backgroundColor = '#28a745'; // Verde sucesso
        notification.style.color = 'white';
        notification.style.padding = '10px 20px';
        notification.style.borderRadius = '5px';
        notification.style.zIndex = '9999';
        notification.style.transition = 'opacity 0.5s ease';
        notification.style.opacity = '1';

        // Adiciona a notificação à página
        document.body.appendChild(notification);

        // Remove a notificação após 2 segundos
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                notification.remove();
            }, 500); // Espera a transição de fade-out terminar
        }, 2000);
    }

    // Função que encontra os links e adiciona o novo comportamento
    const aplicarModificacao = () => {
        const todosOsLinksDeNumero = document.querySelectorAll('a[id*="lvwTriagem_lnkNumero_"]');

        if (todosOsLinksDeNumero.length === 0) {
            return; // Sai se não houver links
        }

        todosOsLinksDeNumero.forEach(link => {
            // Verifica se já modificámos este link para não adicionar múltiplos ouvintes
            if (link.dataset.modificadoParaCopia) {
                return;
            }
            link.dataset.modificadoParaCopia = 'true'; // Marca o link como modificado

            link.addEventListener('click', function(event) {
                // 1. Impede a navegação para a outra página
                event.preventDefault();

                const numeroParaCopiar = event.target.innerText;

                // 2. Usa a API do navegador para copiar o texto
                navigator.clipboard.writeText(numeroParaCopiar).then(() => {
                    // 3. Se a cópia for bem-sucedida, mostra a notificação
                    showCopyNotification(`Número ${numeroParaCopiar} copiado!`);
                }).catch(err => {
                    console.error('Erro ao copiar o número: ', err);
                    showCopyNotification('Falha ao copiar!');
                });
            });
        });
    };

    // --- Lógica do "Vigia" (MutationObserver) para funcionar com paginação ---
    const alvoObservacao = document.getElementById('ConteudoForm_ConteudoGeral_ConteudoFormComAjax_upTriagem');
    if (!alvoObservacao) {
        console.error("Erro Crítico: O container principal das demandas não foi encontrado.");
        return;
    }

    // O vigia executa a função 'aplicarModificacao' sempre que a lista de demandas mudar.
    const observer = new MutationObserver(aplicarModificacao);
    observer.observe(alvoObservacao, { childList: true, subtree: true });

    // Executa uma primeira vez para o caso de o conteúdo já estar na página.
    aplicarModificacao();
    console.log("Observador de links ativado. Os cliques nos números agora irão copiar.");
}

// Chamar a função principal.
modificarLinksParaCopiar();