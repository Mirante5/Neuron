/**
 * @file tratar_novo_insert.js
 * @version 6.0 (Sincronização Robusta)
 * @description Adiciona um listener imediatamente, mas faz o processamento esperar
 * pela inicialização completa do DateUtils, resolvendo a race condition.
 */

(function () {
    'use strict';
    console.log("INSERT v6.0: Script iniciado, listener configurado.");

    let settings = {};

    // Carrega as configurações específicas deste script. Isto pode acontecer em paralelo.
    (async function carregarConfiguracoesInsert() {
        try {
            const result = await chrome.storage.local.get('neuronUserConfig');
            const prazosSettings = result.neuronUserConfig.prazosSettings;
            settings = {
                modoCalculo: prazosSettings.tratarNovoModoCalculo,
                ajusteFds: prazosSettings.tratarNovoAjusteFds,
                ajusteFeriado: prazosSettings.tratarNovoAjusteFeriado,
                diasPrazoInterno: prazosSettings.tratarNovoPrazoInternoDias,
                diasCobrancaInterna: prazosSettings.tratarNovoCobrancaInternaDias
            };
        } catch (e) {
            console.error("INSERT v6.0: Falha ao carregar configurações locais.", e);
        }
    })();
    
    // Ouve o evento imediatamente.
    document.addEventListener('dadosExtraidosNeuron', processarDemandas);

    /**
     * A função que lida com o evento. Ela própria é assíncrona.
     */
    async function processarDemandas(event) {
        try {
            // --- PONTO CRÍTICO DA CORREÇÃO ---
            // A primeira coisa que esta função faz é esperar que a Promise 'ready' 
            // do DateUtils seja resolvida. A execução fica "pausada" aqui até que
            // o DateUtils sinalize que está 100% pronto.
            await window.DateUtils.ready;
            console.log("INSERT v6.0: DateUtils está pronto. Processando dados...");
            
            const demandas = event.detail;
            const DU = window.DateUtils; // Agora é seguro usar o DateUtils.

            demandas.forEach(demanda => {
                if (!demanda.prazo || !demanda.idPrazoOriginal) return;
                const elemPrazo = document.getElementById(demanda.idPrazoOriginal);
                if (!elemPrazo || elemPrazo.parentElement.dataset.calculado) return;

                const dataBase = DU.parsearData(demanda.prazo); // ESTA LINHA AGORA É SEGURA
                if (!dataBase) return;
                
                const containerPrazo = elemPrazo.parentElement;
                containerPrazo.style.display = 'none';
                containerPrazo.dataset.calculado = 'true';

                const elemCadastro = document.getElementById(demanda.idCadastroOriginal);
                if (elemCadastro) elemCadastro.parentElement.style.display = 'none';

                const funcaoDeCalculo = settings.modoCalculo === 'diasUteis' ? DU.adicionarDiasUteis : DU.adicionarDiasCorridos;
                const modoTexto = settings.modoCalculo === 'diasUteis' ? 'Dias Úteis' : 'Dias Corridos';

                const prazoInternoBase = funcaoDeCalculo(dataBase, settings.diasPrazoInterno);
                const cobrancaBase = funcaoDeCalculo(dataBase, settings.diasCobrancaInterna);
                const improrrogavelBase = DU.adicionarDiasCorridos(dataBase, 31);

                const overrideRules = { ajusteFds: settings.ajusteFds, ajusteFeriado: settings.ajusteFeriado };
                
                const prazoFinal = DU.ajustarDataFinal(prazoInternoBase, overrideRules);
                const cobrancaFinal = DU.ajustarDataFinal(cobrancaBase, overrideRules);
                const improrrogavelFinal = DU.ajustarDataFinal(improrrogavelBase, overrideRules);

                let htmlImprorrogavel = '';
                if (!demanda.situacao.includes('Prorrogada')) {
                    htmlImprorrogavel = `<div style="color: #e0a800; font-weight: bold;"><strong>Improrrogável em:</strong> ${DU.formatarData(improrrogavelFinal)}<span style="color: #6c757d; font-style: italic;"> ${DU.calcularDiasRestantes(improrrogavelFinal)}</span></div>`;
                }

                const nossoBloco = document.createElement('div');
                nossoBloco.style.cssText = "border: 1px solid #e0e0e0; border-radius: 5px; padding: 5px; margin-top: 5px; font-size: 0.8em; line-height: 1.8; width: 290px;";
                nossoBloco.innerHTML = `
                    <div style="padding-bottom: 2px; margin-bottom: 2px; border-bottom: 1px dashed #ccc;"><strong>Modo:</strong> ${modoTexto}</div>
                    <div><strong>Cadastro:</strong> ${demanda.dataCadastro}<span style="color: #6c757d; font-style: italic;"> ${DU.calcularDiasRestantes(demanda.dataCadastro)}</span></div>
                    <div><strong>Prazo Original:</strong> ${DU.formatarData(dataBase)}<span style="color: #6c757d; font-style: italic;"> ${DU.calcularDiasRestantes(dataBase)}</span></div>
                    <div style="color: #0056b3;"><strong>Prazo Interno:</strong> ${DU.formatarData(prazoFinal)}<span style="color: #6c757d; font-style: italic;"> ${DU.calcularDiasRestantes(prazoFinal)}</span></div>
                    <div style="color: #c82333;"><strong>Cobrança Interna em:</strong> ${DU.formatarData(cobrancaFinal)}<span style="color: #6c757d; font-style: italic;"> ${DU.calcularDiasRestantes(cobrancaFinal)}</span></div>
                    ${htmlImprorrogavel}
                `;
                
                containerPrazo.insertAdjacentElement('afterend', nossoBloco);
            });
        } catch (error) {
            console.error("INSERT v6.0: Erro durante o processamento de demandas.", error);
        }
    }
})();