/**
 * @file tratar_novo_insert.js
 * @version Final
 * @description Ouve o evento 'dadosExtraidosNeuron' e insere o bloco de prazos na página.
 */

(function () {
    'use strict';
    console.log("INSERT: Script de inserção (Final) iniciado.");

    // 1. MODO DE CÁLCULO INICIAL (Para Prazo Interno e Cobrança)
    const MODO_DE_CALCULO_INICIAL = 'diasCorridos'; // 'diasUteis' ou 'diasCorridos'

    // 2. MODO DE AJUSTE PARA FIM DE SEMANA
    const MODO_AJUSTE_FIM_DE_SEMANA = 'modo1'; // 'modo1', 'modo2' ou 'modo3'

    // 3. MODO DE AJUSTE PARA FERIADOS
    const MODO_AJUSTE_FERIADO = 'proximo_dia'; // 'proximo_dia' ou 'dia_anterior'

    // 4. DIAS PARA CÁLCULO
    const DIAS_DE_CALCULO = {
        prazoInterno: -10,
        cobrancaInterna: -12
    };

    document.addEventListener('dadosExtraidosNeuron', function (event) {
        const demandas = event.detail;
        demandas.forEach(demanda => {
            if (!demanda.prazo || !demanda.idPrazoOriginal) return;
            const elementoPrazoOriginal = document.getElementById(demanda.idPrazoOriginal);
            if (!elementoPrazoOriginal) return;

            const linhaDoPrazoContainer = elementoPrazoOriginal.parentElement;
            if (!linhaDoPrazoContainer || linhaDoPrazoContainer.dataset.calculado) return;

            // Lógica para esconder o container de cadastro
            const elementoCadastroOriginal = document.getElementById(demanda.idCadastroOriginal);
            const linhaDoCadastroContainer = elementoCadastroOriginal ? elementoCadastroOriginal.parentElement : null;
            if (linhaDoCadastroContainer) {
                linhaDoCadastroContainer.style.display = 'none';
            }

            linhaDoPrazoContainer.style.display = 'none';
            const dataBase = parsearData(demanda.prazo);
            if (!dataBase) return;

            // --- Cálculos ---
            const dataCadastro = parsearData(demanda.dataCadastro);
            const funcaoDeCalculo = MODO_DE_CALCULO_INICIAL === 'diasUteis' ? adicionarDiasUteis : adicionarDiasCorridos;
            const modoTexto = MODO_DE_CALCULO_INICIAL === 'diasUteis' ? 'Dias Úteis' : 'Dias Corridos';
            const prazoInternoBase = funcaoDeCalculo(dataBase, DIAS_DE_CALCULO.prazoInterno);
            const cobrancaBase = funcaoDeCalculo(dataBase, DIAS_DE_CALCULO.cobrancaInterna);
            const improrrogavelBase = adicionarDiasCorridos(dataBase, 31);
            const dataPrazoInternoFinal = ajustarDataFinal(prazoInternoBase, MODO_AJUSTE_FIM_DE_SEMANA, MODO_AJUSTE_FERIADO);
            const dataCobrancaFinal = ajustarDataFinal(cobrancaBase, MODO_AJUSTE_FIM_DE_SEMANA, MODO_AJUSTE_FERIADO);
            const dataImprorrogavelFinal = ajustarDataFinal(improrrogavelBase, MODO_AJUSTE_FIM_DE_SEMANA, MODO_AJUSTE_FERIADO);

            let htmlImprorrogavel = '';
            if (!demanda.situacao.includes('Prorrogada')) {
                htmlImprorrogavel = `<div style="color: #e0a800; font-weight: bold;"><strong>Improrrogável em:</strong> ${formatarData(dataImprorrogavelFinal)}<span style="color: #6c757d; font-style: italic;"> ${calcularDiasRestantes(dataImprorrogavelFinal)}</span></div>`;
            }

            const nossoBlocoDeDatas = document.createElement('div');
            nossoBlocoDeDatas.style.cssText = "border: 1px solid #e0e0e0; border-radius: 5px; padding: 5px; margin-top: 5px; font-size: 0.8em; line-height: 1.8; width: 290px;";
            nossoBlocoDeDatas.innerHTML = `
                <div style="padding-bottom: 2px; margin-bottom: 2px; border-bottom: 1px dashed #ccc;"><strong>Modo:</strong> ${modoTexto}</div>
                <div><strong>Cadastro:</strong> ${demanda.dataCadastro}<span style="color: #6c757d; font-style: italic;"> ${calcularDiasRestantes(dataCadastro)}</span></div>
                <div><strong>Prazo Original:</strong> ${formatarData(dataBase)}<span style="color: #6c757d; font-style: italic;"> ${calcularDiasRestantes(dataBase)}</span></div>
                <div style="color: #0056b3;"><strong>Prazo Interno:</strong> ${formatarData(dataPrazoInternoFinal)}<span style="color: #6c757d; font-style: italic;"> ${calcularDiasRestantes(dataPrazoInternoFinal)}</span></div>
                <div style="color: #c82333;"><strong>Cobrança Interna em:</strong> ${formatarData(dataCobrancaFinal)}<span style="color: #6c757d; font-style: italic;"> ${calcularDiasRestantes(dataCobrancaFinal)}</span></div>
                ${htmlImprorrogavel}
            `;

            linhaDoPrazoContainer.insertAdjacentElement('afterend', nossoBlocoDeDatas);
            linhaDoPrazoContainer.dataset.calculado = 'true';
        });
    });
})();