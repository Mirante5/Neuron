/**
 * @file date_utils.js
 * @description Biblioteca avançada de utilidades para cálculos de data,
 * com a lógica de 'calcularDiasRestantes' corrigida e robusta.
 */

// A lista de feriados e as outras funções (isFimDeSemana, isFeriado, etc.) continuam as mesmas.
const FERIADOS_NACIONAIS_2025 = [
    '01-01', '03-03', '03-04', '04-18', '04-21', '05-01', '06-19', 
    '09-07', '10-12', '11-02', '11-15', '11-20', '12-25'
];

function isFimDeSemana(data) {
    const diaDaSemana = data.getDay();
    return diaDaSemana === 0 || diaDaSemana === 6;
}

function isFeriado(data) {
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const dia = String(data.getDate()).padStart(2, '0');
    return FERIADOS_NACIONAIS_2025.includes(`${mes}-${dia}`);
}

function ajustarParaDiaUtil(dataInicial, direcao) {
    let dataAjustada = new Date(dataInicial);
    const incremento = direcao === 'proximo_dia' ? 1 : -1;
    while (isFimDeSemana(dataAjustada) || isFeriado(dataAjustada)) {
        dataAjustada.setDate(dataAjustada.getDate() + incremento);
    }
    return dataAjustada;
}

function parsearData(dataString) {
    if (!dataString) return null;
    const partes = dataString.split('/');
    if (partes.length !== 3) return null;
    const dia = parseInt(partes[0], 10);
    const mes = parseInt(partes[1], 10) - 1;
    const ano = parseInt(partes[2], 10);
    return new Date(ano, mes, dia, 12, 0, 0);
}

function formatarData(data) {
    if (!data) return '';
    const dia = String(data.getDate()).padStart(2, '0');
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const ano = data.getFullYear();
    return `${dia}/${mes}/${ano}`;
}

// =================================================================
// ***** FUNÇÃO CORRIGIDA *****
// =================================================================
function calcularDiasRestantes(dataAlvo) {
    if (!dataAlvo) return '';
    const hoje = new Date();
    hoje.setHours(12, 0, 0, 0); // Normaliza a data de hoje para meio-dia

    const dataAlvoNormalizada = new Date(dataAlvo);
    dataAlvoNormalizada.setHours(12, 0, 0, 0); // Garante que a data alvo também está a meio-dia

    const diferencaMs = dataAlvoNormalizada.getTime() - hoje.getTime();
    
    // Usamos Math.round para o cálculo mais natural de dias.
    const dias = Math.round(diferencaMs / (1000 * 60 * 60 * 24));

    // Lógica de exibição corrigida
    if (dias === -1) return '[Ontem]';
    if (dias < -1) return `[${Math.abs(dias)} dias atrás]`;
    if (dias === 0) return '[Hoje]';
    if (dias === 1) return '[Amanhã]';
    if (dias > 1) return `[${dias} dias restantes]`;
    return ''; // Caso seja um valor inesperado
}
// =================================================================

function adicionarDiasCorridos(dataInicial, dias) {
    const novaData = new Date(dataInicial);
    novaData.setDate(novaData.getDate() + dias);
    return novaData;
}

function adicionarDiasUteis(dataInicial, diasUteis) {
    const novaData = new Date(dataInicial);
    let diasAdicionados = 0;
    const incremento = diasUteis > 0 ? 1 : -1;
    while (diasAdicionados < Math.abs(diasUteis)) {
        novaData.setDate(novaData.getDate() + incremento);
        const diaDaSemana = novaData.getDay();
        if (diaDaSemana !== 0 && diaDaSemana !== 6) {
            diasAdicionados++;
        }
    }
    return novaData;
}

function ajustarDataFinal(dataCalculada, modoFimDeSemana, modoFeriado) {
    let dataAjustada = new Date(dataCalculada);
    const diaDaSemana = dataAjustada.getDay();

    if (diaDaSemana === 6) { // Sábado
        if (modoFimDeSemana === 'modo1' || modoFimDeSemana === 'modo2') dataAjustada.setDate(dataAjustada.getDate() - 1);
        else if (modoFimDeSemana === 'modo3') dataAjustada.setDate(dataAjustada.getDate() + 2);
    } else if (diaDaSemana === 0) { // Domingo
        if (modoFimDeSemana === 'modo1' || modoFimDeSemana === 'modo3') dataAjustada.setDate(dataAjustada.getDate() + 1);
        else if (modoFimDeSemana === 'modo2') dataAjustada.setDate(dataAjustada.getDate() - 2);
    }

    if (isFeriado(dataAjustada)) {
        dataAjustada = ajustarParaDiaUtil(dataAjustada, modoFeriado);
    }
    
    return dataAjustada;
}