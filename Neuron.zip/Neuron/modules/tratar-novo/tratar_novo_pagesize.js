/**
 * @file tratar_novo_pagesize.js
 * @version 5.0 (Sem Fallback - Direto)
 * @description Lê a configuração de itens por página diretamente do storage,
 * altera o valor na página e clica no botão de confirmação.
 */

(function() {
    'use strict';
    console.log("PAGE_SIZE: Script de vigia v5 iniciado.");

    const idDoCampo = 'ConteudoForm_ConteudoGeral_ConteudoFormComAjax_pagTriagem_ctl03_txtTamanhoPagina';
    const idDoBotao = 'ConteudoForm_ConteudoGeral_ConteudoFormComAjax_pagTriagem_ctl03_btnAlterarTamanhoPagina';
    let debounceTimer;
    let itensPorPaginaDesejado; // Será definido ao carregar a configuração

    /**
     * Carrega as configurações do Chrome Storage.
     * Assume que a configuração sempre existe.
     */
    async function carregarConfiguracoes() {
        const result = await chrome.storage.local.get('neuronUserConfig');
        // Converte o número para string, pois o campo na página é um texto.
        itensPorPaginaDesejado = String(result.neuronUserConfig.generalSettings.qtdItensTratarTriar);
        console.log(`PAGE_SIZE: Configuração carregada. Itens por página definido para: ${itensPorPaginaDesejado}`);
    }

    /**
     * Função que verifica o valor na página e age apenas se for necessário.
     */
    function verificarEAtualizarTamanho() {
        const campoTamanho = document.getElementById(idDoCampo);
        const botaoConfirmar = document.getElementById(idDoBotao);

        if (!campoTamanho || !botaoConfirmar) {
            return;
        }

        if (campoTamanho.value === itensPorPaginaDesejado) {
            return;
        }

        console.log(`PAGE_SIZE: Valor incorreto detectado (${campoTamanho.value}). Corrigindo para ${itensPorPaginaDesejado}...`);

        campoTamanho.value = itensPorPaginaDesejado;
        console.log("PAGE_SIZE: A clicar no botão de confirmação...");
        botaoConfirmar.click();
    }

    /**
     * Função que é chamada a cada mutação na página, com um debounce.
     */
    const onPageChange = () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(verificarEAtualizarTamanho, 300);
    };

    /**
     * Função principal que inicializa o script.
     */
    async function init() {
        await carregarConfiguracoes(); // Carrega as configurações primeiro

        // Configura o observer para reagir a mudanças
        const observer = new MutationObserver(onPageChange);

        window.addEventListener('load', () => {
            console.log("PAGE_SIZE: Página carregada. Iniciando o observador.");
            if (document.body) {
                observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });
                onPageChange(); // Verificação inicial
            }
        });
    }

    init();

})();