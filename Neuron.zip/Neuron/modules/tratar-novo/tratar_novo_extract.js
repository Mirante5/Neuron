/**
 * @file tratar_novo_extract.js
 * @version Final (Correção Definitiva de Ícones)
 * @description Versão com a lógica de extração de ícones corrigida e robusta.
 * Garante que o sinal 'dadosExtraidosNeuron' seja sempre enviado.
 */

(function() {
    'use strict';
    console.log("EXTRACT: Script de extração (Correção Definitiva) iniciado.");
    let debounceTimer;

    const executarExtracao = () => {
        const todosOsLinksDeNumero = document.querySelectorAll('a[id*="lvwTriagem_lnkNumero_"]');
        if (todosOsLinksDeNumero.length === 0) return;

        console.log(`EXTRACT: Foram encontradas ${todosOsLinksDeNumero.length} demandas na página. Processando...`);
        const manifestacoesParaProcessar = [];

        todosOsLinksDeNumero.forEach(linkNumero => {
            try {
                // Extração fiável via ID
                const idCompleto = linkNumero.id;
                const indice = idCompleto.split('_').pop();
                const situacaoElement = document.getElementById(`ConteudoForm_ConteudoGeral_ConteudoFormComAjax_lvwTriagem_lblSituacaoManifestacao_${indice}`);
                const prazoElement = document.getElementById(`ConteudoForm_ConteudoGeral_ConteudoFormComAjax_lvwTriagem_lblPrazoResposta_${indice}`);
                const cadastroElement = document.getElementById(`ConteudoForm_ConteudoGeral_ConteudoFormComAjax_lvwTriagem_lblDataRegistro_${indice}`);
                const urlRelativo = linkNumero.getAttribute('navigateurl');

                // LÓGICA DE EXTRAÇÃO DE ÍCONES CORRIGIDA
                let iconeRespondida = null;
                let iconeObservacao = null;

                // 1. Encontra o primeiro .row, que contém o link do número.
                const primeiroRow = linkNumero.closest('.row');
                if (primeiroRow) {
                    // 2. O segundo .row, que é o irmão seguinte, contém os detalhes.
                    const segundoRow = primeiroRow.nextElementSibling;
                    if (segundoRow && segundoRow.classList.contains('row')) {
                        const colunaDetalhes = segundoRow.querySelector('.coluna2dalista');
                        if (colunaDetalhes) {
                            iconeRespondida = colunaDetalhes.querySelector('em.fas.fa-check-circle[style*="green"]');
                            // 3. O seletor para o olho agora é mais flexível e correto.
                            iconeObservacao = colunaDetalhes.querySelector('em.fas.fa-eye');
                        }
                    }
                }

                manifestacoesParaProcessar.push({
                    numero: linkNumero.innerText.trim(),
                    href: urlRelativo ? `https://falabr.cgu.gov.br${urlRelativo}` : null,
                    situacao: situacaoElement?.innerText.trim() || '',
                    prazo: prazoElement?.innerText.trim() || '',
                    dataCadastro: cadastroElement?.innerText.trim() || '',
                    possivelRespondida: !!iconeRespondida,
                    possivelobservacao: !!iconeObservacao, // Agora funciona!
                    idPrazoOriginal: prazoElement?.id || null,
                    idCadastroOriginal: cadastroElement?.id || null
                });
            } catch (error) {
                console.error("EXTRACT: Erro ao extrair demanda:", linkNumero.innerText.trim(), error);
            }
        });

        if (manifestacoesParaProcessar.length > 0) {
            console.log(`EXTRACT: Extração concluída. Emitindo sinal 'dadosExtraidosNeuron' com ${manifestacoesParaProcessar.length} demandas.`);
            const evento = new CustomEvent('dadosExtraidosNeuron', { detail: manifestacoesParaProcessar });
            document.dispatchEvent(evento);
        }
    };

    const onMutation = () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(executarExtracao, 500);
    };
    document.addEventListener('NEURON_SOLICITAR_ATUALIZACAO', executarExtracao);
    const alvoObservacao = document.getElementById('ConteudoForm_ConteudoGeral_ConteudoFormComAjax_upTriagem');
    if (alvoObservacao) {
        const observer = new MutationObserver(onMutation);
        observer.observe(alvoObservacao, { childList: true, subtree: true });
        onMutation();
    }
})();